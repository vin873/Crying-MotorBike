#include "mainpp.h"
#include "ros.h"
#include "std_msgs/Float64MultiArray.h"

ros::NodeHandle nh;

double flt_temp[10];
std_msgs::Float64MultiArray flt_msg;
ros::Publisher pub_imu_data("imu_data", &flt_msg);

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	nh.getHardware()->flush();
}

void HardwareInit(void)
{
	nh.getHardware()->init();
}

void setup(void)
{
	nh.initNode();
	nh.advertise(pub_imu_data);
}

void pub_imu()
{
	flt_msg.data_length = 10;
	flt_msg.data = flt_temp;
	flt_temp[0] = inclination;
	for (int i = 0;i < 3;i ++)
	{
		flt_temp[i+1] = pry[i];
	}
	for (int i = 0;i < 3;i ++)
	{
		flt_temp[i+4] = angular_V[i];
	}
	for (int i = 0;i < 3;i ++)
	{
		flt_temp[i+7] = acceleration[i];
	}
	pub_imu_data.publish(&flt_msg);
}

void loop(void)
{
	nh.spinOnce();
}
