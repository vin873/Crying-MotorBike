/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "mainpp.h"
#include "xsens_mti.h"
#include "xsens_utility.h"
#include "math.h"
#include "stdbool.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
float euler_rpy[3] = { 0 };
int flag = 0, caliTimes = 200, get_byte = 61;
int timer2_count = 0, timerct = 0, timerct2 = 0;
float first[3] = { 0 }, second[3] = { 0 };
uint8_t Rx_data[62];
void imu_callback( XsensEventFlag_t event, XsensEventData_t *mtdata );
xsens_interface_t imu_interface = XSENS_INTERFACE_RX( &imu_callback );



float lastMotorError = 0, targetPos, yaw_int = 0, time_interval = 0.00984, tt;
bool LR = 0;

int time1 = 0, time2 = 0, toggleCount = 0, start_reset;

CAN_TxHeaderTypeDef TxHeader;
CAN_RxHeaderTypeDef RxHeader;

uint8_t TxData[8];
uint8_t RxData[8];
uint16_t iqControl;
uint32_t TxMailbox;

//uint8_t Start_Motor[8] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFC};
//uint8_t Run_Mode[8] = {0x7F,0xFF,0x7F,0xF0,0x00,0x00,0x07,0xFF};
//uint8_t Back_to_Origin[8] = {0x7F,0xFF,0x7F,0xF0,0x18,0x0B,0xC7,0xFF};
//uint8_t Stop_Motor[8] = {0x81,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
//uint8_t Running_Motor[8] = {0xA1,0x00,0x00,0x00,*(uint8_t *)(&iqControl),*((uint8_t *)(&iqControl)+1),0x00,0x00}; //RMD

uint16_t Position;
float M_Position;

int Runcheck = 0;
int count = 0;
int State = 0;
int connect = 0;
int unconnect = 1;
int Stop = 0;
int Stop_1 = 0;
int Stop_Check = 2;

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;
DMA_HandleTypeDef hdma_usart3_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_CAN1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	HAL_UART_Receive_DMA(&huart3, Rx_data, get_byte);
}

float crossProduct(float first[], float second[])
{
	float result[3], angle;
	result[0] = first[1] * second[2] - first[2] * second[1];
	result[1] = first[2] * second[0] - first[0] * second[2];
	result[2] = first[0] * second[1] - first[1] * second[0];
	angle = acos(result[2]/(pow((pow(result[0],2)+pow(result[1],2)+pow(result[2],2)),0.5)));
	angle *= (180.0 / M_PI);
	return angle;
}

void imu_callback( XsensEventFlag_t event, XsensEventData_t *mtdata )
{
	switch( event )
	{
	case XSENS_EVT_QUATERNION:
		// We use the type field of XsensEventData_t as a doublecheck before
		// blindly copying bytes out of the union
		if( mtdata->type == XSENS_EVT_TYPE_FLOAT4 )
		{
			// Convert the quaternion to euler angles
			xsens_quaternion_to_euler( mtdata->data.f4x4, euler_rpy );
			first[0] = cos(euler_rpy[0]);
			first[1] = 0;
			first[2] = sin(euler_rpy[0]);
			second[0]= 0;
			second[1] = cos(euler_rpy[1]);
			second[2] = sin(euler_rpy[1]);
			inclination = crossProduct(first, second);
			for (int i = 0;i < 3;i++)
			{
				rpy[i] = euler_rpy[i] / M_PI * 180;
			}
			if (__HAL_TIM_GET_COUNTER(&htim2) - timerct >= 500)
			{
				pub_imu();
				timerct = __HAL_TIM_GET_COUNTER(&htim2);
			}
		}
		break;

	case XSENS_EVT_RATE_OF_TURN:
		if( mtdata->type == XSENS_EVT_TYPE_FLOAT3 )
		{
			angular_V[0] = mtdata->data.f4x3[0];
			angular_V[1] = mtdata->data.f4x3[1];
			angular_V[2] = mtdata->data.f4x3[2];
		}
		break;


	case XSENS_EVT_ACCELERATION:
		if( mtdata->type == XSENS_EVT_TYPE_FLOAT3 )
		{
			acceleration[0] = mtdata->data.f4x3[0];
			acceleration[1] = mtdata->data.f4x3[1];
			acceleration[2] = mtdata->data.f4x3[2];
		}
		break;

	case XSENS_EVT_FREE_ACCELERATION:
		if( mtdata->type == XSENS_EVT_TYPE_FLOAT3 )
		{
			acceleration[0] = mtdata->data.f4x3[0];
			acceleration[1] = mtdata->data.f4x3[1];
			acceleration[2] = mtdata->data.f4x3[2];
		}
		break;
	}
}

void UART_Send(uint8_t u8_data)
{
	uint8_t* u8_pointer = &u8_data;
	HAL_UART_Transmit(&huart3, u8_pointer, 1, 100);
}

void UART_Send_Motor()
{
	UART_Send(0x3E);
	UART_Send(0xA1);
	UART_Send(0x01);
	UART_Send(0x02);
	UART_Send(0xE2);
	UART_Send(0x96);
	UART_Send(0x00);
	UART_Send(0x96);
}

void UART_Send_GyroBiasEst()
{
	//	SetNoRotation
	UART_Send(0xFA);
	UART_Send(0xFF);
	UART_Send(0x22);
	UART_Send(0x02);
	UART_Send(0x00);
	// Time
	//	UART_Send(0x04);
	//	UART_Send(0xD9);
	//	UART_Send(0x0A);
	//	UART_Send(0xD3);
	UART_Send(0x10);
	UART_Send(0xCD);
}

void UART_Send_ResetHeading()
{
	// ResetOrientation - Heading
	UART_Send(0xFA);
	UART_Send(0xFF);
	UART_Send(0xA4);
	UART_Send(0x02);
	UART_Send(0x00);
	UART_Send(0x01);
	UART_Send(0x5A);

	// ResetOrientation - Align
	UART_Send(0xFA);
	UART_Send(0xFF);
	UART_Send(0xA4);
	UART_Send(0x02);
	UART_Send(0x00);
	UART_Send(0x04);
	UART_Send(0x57);

	// ResetOrientation - Store Current
	UART_Send(0xFA);
	UART_Send(0xFF);
	UART_Send(0xA4);
	UART_Send(0x02);
	UART_Send(0x00);
	UART_Send(0x00);
	UART_Send(0x5B);
}

float constrain(float var, float range0, float range1)
{
	if (var < range0)
	{
		var = range0;
	}
	else if (var > range1)
	{
		var = range1;
	}
	return var;
}

void pub_back(uint16_t iqControl)
{
	//
	if (count % 2 == 0)
	{
		TxData[0] = 0x92;
		TxData[1] = 0x00;
		TxData[2] = 0x00;
		TxData[3] = 0x00;
		TxData[4] = 0x00;
		TxData[5] = 0x00;
		TxData[6] = 0x00;
		TxData[7] = 0x00;
	}
	else
	{
		TxData[0] = 0xA1;
		TxData[1] = 0x00;
		TxData[2] = 0x00;
		TxData[3] = 0x00;
		TxData[4] = *(uint8_t *)(&iqControl);
		TxData[5] = *((uint8_t *)(&iqControl)+1);
		TxData[6] = 0x00;
		TxData[7] = 0x00;
	}

	//	TxData[0] = 0x9C;
	//	TxData[1] = 0x00;
	//	TxData[2] = 0x00;
	//	TxData[3] = 0x00;
	//	TxData[4] = 0x00;
	//	TxData[5] = 0x00;
	//	TxData[6] = 0x00;
	//	TxData[7] = 0x00;

	TxHeader.DLC = 8; //data length
	TxHeader.IDE = CAN_ID_STD;
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.StdId = 0x141; //ID

	if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox) == HAL_OK)
	{
		count ++;
	}
}

void commander()
{
	targetPos = constrain((Kp_p*rpy[0] + Ki_p*yaw_int + constrain(Kd_p*angular_V[0],-posLimit,posLimit)),-posLimit,posLimit);
	//	if (RxData[0] == 0x92)
	//	{
	motorError = motorPos - targetPos;
	motorErrorI += motorError * rate;
	motorErrorI = constrain(motorErrorI, -effortLimit, effortLimit);
	time2 = __HAL_TIM_GET_COUNTER(&htim2);
	if (time2 <= time1)
	{
		time2 += 999;
	}
	motorErrorD = constrain((motorError - lastMotorError) / ((time2-time1)*0.000001), -100, 100);
	time1= __HAL_TIM_GET_COUNTER(&htim2);
	lastMotorError = motorError;
	pid_output = Kp_e*motorError + Ki_e*motorErrorI + Kd_e*motorErrorD;
	actual_output = -constrain(pid_output, -effortLimit, effortLimit);
	//	}
	pub_back(actual_output);
	yaw_int += rpy[0] * 0.01;
	yaw_int = constrain(yaw_int, -0.3, 0.3);
	//	pub_pid();
	//	pub_imu();
	if (RxData[0] == 0xA1)
	{
		pub_targetPos();
		pub_motorPos();
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_13)
	{
		State += 1;
	}
}

void Motor_State_Convert(uint16_t MxData)
{
	//	motorPos = MxData[7] + MxData[6]/256.0;
	if (start_reset == 0)
	{
		if (motorPos <= 127)
		{
			LR = 1;
		}
	}
	if ((lastMotorPos<=35 && lastMotorPos>=-36) && (lastLastMotorPos<=35 && lastLastMotorPos>=-36)){
		angularVelocity = 0;
	}
	else
	{
		angularVelocity = lastMotorPos - lastLastMotorPos;
	}
	if (motorPos <= 35)
	{
		LR = 1;
	}
	else if (motorPos >= 220)
	{
		LR = 0;
	}
	else if (!LR && motorPos > 35 && actual_output > 0 && angularVelocity > 15)
	{
		LR = 1;
	}
	else if (LR && motorPos < 220 && actual_output < 0 && angularVelocity < -15)
	{
		LR = 0;
	}

	pub_angV();
	if (!LR)
	{
		motorPos -= 256;
	}
	lastLastMotorPos = lastMotorPos;
	lastMotorPos = motorPos;
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, RxData);
	if (RxData[0] == 0x92)
	{
		if (RxData[3] == 255)
		{
			LR = 0;
		}
		else if (RxData[3] == 0)
		{
			LR = 1;
		}
		if (LR)
		{
			motorPos = RxData[2] + RxData[1]/256.0;
		}
		else
		{
			motorPos = RxData[2] + RxData[1]/256.0 - 256;
		}
	}

	if (RxHeader.DLC == 8)
	{
		connect = 1;
		Stop += 1;
	}
	else
	{
		connect = 0;
	}
}

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USART3_UART_Init();
	MX_USART2_UART_Init();
	MX_TIM2_Init();
	MX_CAN1_Init();
	/* USER CODE BEGIN 2 */
	setup();
	UART_Send_GyroBiasEst();
	for(int i = 0;i < 100;i++)
	{
		UART_Send_ResetHeading();
	}
	UART_Send_Motor();

	motorPos = 0;
	motorError = 0;
	motorErrorI = 0;
	motorErrorD = 0;
	targetPos = 60;
	Kp_p = 6.8;
	Ki_p = 0;
	Kd_p = 8.7;
	posLimit = 110;

	effortLimit = 450;
	Kp_e = 25;
	Ki_e = 0.085;
	Kd_e = 1.4;
	rate = 0.09;
	start = 0;
	actual_output = 0;
	HAL_TIM_Base_Start_IT(&htim2);

	HAL_CAN_Start(&hcan1);
	//	HAL_TIM_Base_Start_IT(&htim3);
	HAL_CAN_ActivateNotification(&hcan1,CAN_IT_RX_FIFO0_MSG_PENDING);

	//	TxHeader.DLC = 8; //data length
	//	TxHeader.IDE = CAN_ID_STD;
	//	TxHeader.RTR = CAN_RTR_DATA;
	//	TxHeader.StdId = 0x141; //IDco

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		HAL_UART_Receive_DMA(&huart3, Rx_data, get_byte);
		xsens_mti_parse_buffer(&imu_interface, Rx_data, get_byte);
		if (start != 0)
		{
			if (start_reset == 0)
			{
				motorPos = 150;
				targetPos = 150;
				UART_Send_GyroBiasEst();
				motorPos = -150;
				targetPos = -150;
				for(int i = 0;i < 100;i++)
				{
					UART_Send_ResetHeading();
				}
				UART_Send_Motor();
				motorPos = 0;
				targetPos = 0;
				start_reset = 1;
			}
			if (__HAL_TIM_GET_COUNTER(&htim2) - timerct >= 500)
			{
				toggleCount++;
				if(toggleCount == 5000)
				{
					//targetPos*=-1;
					toggleCount = 0;
				}
				commander();
				timerct = __HAL_TIM_GET_COUNTER(&htim2);
			}
		}

		loop();
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 8;
	RCC_OscInitStruct.PLL.PLLN = 180;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 2;
	RCC_OscInitStruct.PLL.PLLR = 2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}
	/** Activate the Over-Drive mode
	 */
	if (HAL_PWREx_EnableOverDrive() != HAL_OK)
	{
		Error_Handler();
	}
	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
			|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief CAN1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_CAN1_Init(void)
{

	/* USER CODE BEGIN CAN1_Init 0 */

	/* USER CODE END CAN1_Init 0 */

	/* USER CODE BEGIN CAN1_Init 1 */

	/* USER CODE END CAN1_Init 1 */
	hcan1.Instance = CAN1;
	hcan1.Init.Prescaler = 9;
	hcan1.Init.Mode = CAN_MODE_NORMAL;
	hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
	hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
	hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
	hcan1.Init.TimeTriggeredMode = DISABLE;
	hcan1.Init.AutoBusOff = DISABLE;
	hcan1.Init.AutoWakeUp = DISABLE;
	hcan1.Init.AutoRetransmission = DISABLE;
	hcan1.Init.ReceiveFifoLocked = DISABLE;
	hcan1.Init.TransmitFifoPriority = DISABLE;
	if (HAL_CAN_Init(&hcan1) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN CAN1_Init 2 */
	CAN_FilterTypeDef canfilterconfig;

	canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
	canfilterconfig.FilterBank = 18;
	canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	canfilterconfig.FilterIdHigh =  0x000<<5;  //Identifier
	canfilterconfig.FilterIdLow = 0;
	canfilterconfig.FilterMaskIdHigh = 0x000<<5;
	canfilterconfig.FilterMaskIdLow = 0x0000;
	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
	canfilterconfig.SlaveStartFilterBank = 20;

	HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);
	/* USER CODE END CAN1_Init 2 */

}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM2_Init(void)
{

	/* USER CODE BEGIN TIM2_Init 0 */

	/* USER CODE END TIM2_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM2_Init 1 */

	/* USER CODE END TIM2_Init 1 */
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 89;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 999;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM2_Init 2 */

	/* USER CODE END TIM2_Init 2 */

}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void)
{

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */

	/* USER CODE END USART2_Init 2 */

}

/**
 * @brief USART3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART3_UART_Init(void)
{

	/* USER CODE BEGIN USART3_Init 0 */

	/* USER CODE END USART3_Init 0 */

	/* USER CODE BEGIN USART3_Init 1 */

	/* USER CODE END USART3_Init 1 */
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 115200;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart3) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART3_Init 2 */

	/* USER CODE END USART3_Init 2 */

}

/**
 * Enable DMA controller clock
 */
static void MX_DMA_Init(void)
{

	/* DMA controller clock enable */
	__HAL_RCC_DMA1_CLK_ENABLE();

	/* DMA interrupt init */
	/* DMA1_Stream1_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
	/* DMA1_Stream5_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
	/* DMA1_Stream6_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void)
{

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
	if(huart == &huart2)
	{
		HAL_UART_DeInit(&huart2);
		MX_USART2_UART_Init();
		HardwareInit();
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim){
	if(htim->Instance == TIM2){
		//		if(State==0){
		//			//			if(connect==0){
		//			//				//TxHeader.StdId = 0x002; //ID
		//			//				TxHeader.StdId = 0x141; //ID
		//			//				//HAL_CAN_AddTxMessage(&hcan1, &TxHeader,Start_Motor , &TxMailbox); //Start_Motor
		//			//				HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData , &TxMailbox); //Running_Motor
		//			//			}
		//			//			if(connect==1){
		//			//			TxData[0] = 0xA1;
		//			//			TxData[1] = 0x00;
		//			//			TxData[2] = 0x00;
		//			//			TxData[3] = 0x00;
		//			//			TxData[4] = *(uint8_t *)(&iqControl);
		//			//			TxData[5] = *((uint8_t *)(&iqControl)+1);
		//			//			TxData[6] = 0x00;
		//			//			TxData[7] = 0x00;
		//			//TxHeader.StdId = 0x002; //ID
		//			//HAL_CAN_AddTxMessage(&hcan1, &TxHeader,Back_to_Origin , &TxMailbox); //Run_mode
		//			//			TxHeader.StdId = 0x141; //ID
		//			//HAL_CAN_AddTxMessage(&hcan1, &TxHeader,Start_Motor , &TxMailbox); //Start_Motor
		////			HAL_CAN_AddTxMessage(&hcan1, &TxHeader,TxData , &TxMailbox); //Running_Motor
		//			//				HAL_CAN_AddTxMessage(&hcan1, &TxHeader,Stop_Motor , &TxMailbox); //Running_Motor
		//			//			}
		//		}
		//		else{
		//			TxHeader.StdId = 0x002; //ID
		//			HAL_CAN_AddTxMessage(&hcan1, &TxHeader,Stop_Motor , &TxMailbox); //Stop_Motor
		//		}
	}
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
