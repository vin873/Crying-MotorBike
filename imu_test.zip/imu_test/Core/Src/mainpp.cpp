#include "mainpp.h"
#include "ros.h"
#include "std_msgs/Float64MultiArray.h"

ros::NodeHandle nh;

double flt_temp[4];
std_msgs::Float64MultiArray flt_msg;
ros::Publisher pub_pry("imu_pry", &flt_msg);

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	nh.getHardware()->flush();
}

void HardwareInit(void)
{
	nh.getHardware()->init();
}

void setup(void)
{
	nh.initNode();
	nh.advertise(pub_pry);
}

void pub_imu()
{
	flt_msg.data_length = 4;
	flt_msg.data = flt_temp;
	flt_temp[0] = inclination;
	for (int i = 0;i < 3;i ++)
	{
		flt_temp[i+1] = pry[i];
	}
	pub_pry.publish(&flt_msg);
}

void loop(void)
{
	nh.spinOnce();
}
