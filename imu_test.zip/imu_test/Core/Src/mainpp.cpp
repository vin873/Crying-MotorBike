#include "mainpp.h"
#include "ros.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Float64MultiArray.h"

ros::NodeHandle nh;

void motor_callback(const std_msgs::Float64 &msg)
{
	motorPos = msg.data;
}

void yangle_callback(const std_msgs::Float64 &msg)
{
	rpy[0] = msg.data;
}

void yangular_callback(const std_msgs::Float64 &msg)
{
	angular_V[0] = msg.data;
}

void kp_callback(const std_msgs::Float64 &msg)
{
	Kp_e = msg.data;
}
void ki_callback(const std_msgs::Float64 &msg)
{
	Ki_e = msg.data;
}
void kd_callback(const std_msgs::Float64 &msg)
{
	Kd_e = msg.data;
}
void start_callback(const std_msgs::Float64 &msg)
{
	start = msg.data;
}
void effort_callback(const std_msgs::Float64 &msg)
{
	effortLimit = msg.data;
}

double flt_temp[4];
std_msgs::Float64 pid_msg;
std_msgs::Float64MultiArray flt_msg;
std_msgs::Float64 flt_msg2;
std_msgs::Float64 flt_msg3;
//ros::Subscriber<std_msgs::Float64> sub0("motorPos", motor_callback);
ros::Subscriber<std_msgs::Float64> sub1("yangle", yangle_callback);
ros::Subscriber<std_msgs::Float64> sub2("yangular", yangular_callback);
ros::Subscriber<std_msgs::Float64> sub3("Kp", kp_callback);
ros::Subscriber<std_msgs::Float64> sub4("Ki", ki_callback);
ros::Subscriber<std_msgs::Float64> sub5("Kd", kd_callback);
ros::Subscriber<std_msgs::Float64> sub6("startornot", start_callback);
ros::Subscriber<std_msgs::Float64> sub7("effortLimit", effort_callback);
ros::Publisher pub_pid_data("pid_pub", &flt_msg);
ros::Publisher targetPos_data("targetPos", &flt_msg2);
ros::Publisher motorPos_data("motorPos", &flt_msg3);
//ros::Publisher pub_imu_data("imu_pub", &flt_msg);

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	nh.getHardware()->flush();
}

void HardwareInit(void)
{
	nh.getHardware()->init();
}

void setup(void)
{
	nh.initNode();
	nh.advertise(pub_pid_data);
	nh.advertise(targetPos_data);
	nh.advertise(motorPos_data);
//	nh.advertise(pub_imu_data);
//	nh.subscribe(sub0);
	nh.subscribe(sub1);
	nh.subscribe(sub2);
	nh.subscribe(sub3);
	nh.subscribe(sub4);
	nh.subscribe(sub5);
	nh.subscribe(sub6);
	nh.subscribe(sub7);
}

//void pub_imu()
//{
//	flt_msg.data_length = 10;
//	flt_msg.data = flt_temp;
//	flt_temp[0] = inclination;
//	for (int i = 0;i < 3;i ++)
//	{
//		flt_temp[i+1] = rpy[i];
//	}
//	for (int i = 0;i < 3;i ++)
//	{
//		flt_temp[i+4] = angular_V[i];
//	}
//	for (int i = 0;i < 3;i ++)
//	{
//		flt_temp[i+7] = acceleration[i];
//	}
//	pub_imu_data.publish(&flt_msg);
//}

void pub_pid()
{
	flt_msg.data_length = 4;
	flt_msg.data = flt_temp;
	flt_temp[0] = pid_output;
	flt_temp[1] = motorError;
	flt_temp[2] = motorErrorI;
	flt_temp[3] = motorErrorD;
	pub_pid_data.publish(&flt_msg);
}

void pub_targetPos()
{
	flt_msg2.data = targetPos;
	targetPos_data.publish(&flt_msg2);
}

void pub_motorPos()
{
	flt_msg3.data = motorPos;
	motorPos_data.publish(&flt_msg3);
}

void loop(void)
{
	nh.spinOnce();
}
