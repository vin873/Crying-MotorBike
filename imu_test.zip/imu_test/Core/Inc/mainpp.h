/*
 * mainpp.h
 *
 *  Created on: 2018/01/17
 *      Author: yoneken
 */

#ifndef MAINPP_H_
#define MAINPP_H_

#ifdef __cplusplus
 extern "C" {
#endif

void setup(void);
void loop(void);
float inclination, rpy[3], angular_V[3], acceleration[3], pid_output, motorError, motorErrorI, motorErrorD, motorPos, Kp_p, Ki_p, Kd_p, Kp_e, Ki_e, Kd_e, targetPos, start, effortLimit;
void HardwareInit(void);
void pub_pid();
void pub_imu();
void pub_targetPos();
void pub_motorPos();

#ifdef __cplusplus
}
#endif


#endif /* MAINPP_H_ */
